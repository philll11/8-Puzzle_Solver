#include <iostream>

using namespace std;

long long computeHash(string const& s);